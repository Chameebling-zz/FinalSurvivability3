package render;

import java.awt.*;

public class ProjPolygon extends Polygon {
	
	public ProjPolygon(){
		super();
	}
	
	public ProjPolygon(int[] xpoints, int[] ypoints, int npoints){
		super(xpoints,ypoints,npoints);
	}
	
	public void minX(){
		
	}
	
	public void maxX(){
		
	}
	
	public void minY(){
		
	}
	
	public void maxY(){
		
	}
	
}