package render;

import assets.*;
import main.*;
import map.*;
import screen.*;

import java.awt.*;
import java.util.*;
import java.awt.image.*;

/*
 * Camera.java
 * Assignment: Final Project 2018-19 (Game: Survivability 3)
 * Purpose: Show what you learned in the APCS class (e.g. inheritance, interfaces, ArrayLists, etc.)
 * @version --/--/-- because I'm still working on this class!!!
 * 
 * TODO: Fix depth sensing issue by possibly using Polygon class!
 */

public class Camera {
	
	public final int CHUNK_LENGTH = 16;
	
	public final AlphaComposite src_over = AlphaComposite.getInstance(AlphaComposite.SRC_OVER);
	public final AlphaComposite dst_over = AlphaComposite.getInstance(AlphaComposite.DST_OVER);
	
	private GameMap map;
	private Screen screen;
	private BufferedImage image;
	private Graphics2D g2d;
	
	private double[] pos, rot, surface;
	
	private Chunk[][] chunks;
	
	private Point3D[] currentMapPixCorners;
	
	private Point3D[] currentPartCorners;
	
	private int[] projCornersX, projCornersY;
	
	private Point currentChunk;
	
	private ArrayList<Chunk> orderedChunks;
	private ArrayList<Part> orderedParts;
	
	public Camera(GameMap map, CameraScreen screen, double[] pos, double[] rot, double dist) {
		
		long msStart = Calendar.getInstance().getTimeInMillis();
		
		// Initializes all the fields!
		this.map = map;
		this.screen = screen;
		image = screen.getImage();
		
		// - Gets and configures the Graphics2D class properly!
		Graphics g = image.getGraphics();
		g2d = (Graphics2D) g;
		g2d.setComposite(src_over);
		RenderingHints rh = new RenderingHints(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
		g2d.setRenderingHints(rh);
		
		this.pos = pos;
		this.rot = rot;
		
		// - Initializes object fields by constructing them so we don't have to deal w/ this later!
		surface = new double[] {0, 0, dist};
		chunks = new Chunk[CHUNK_LENGTH][CHUNK_LENGTH];
		currentMapPixCorners = new Point3D[4];
		currentPartCorners = new Point3D[4];
		projCornersX = new int[4];
		projCornersY = new int[4];
		currentChunk = new Point();
		orderedChunks = new ArrayList<Chunk>();
		orderedParts = new ArrayList<Part>();
		
		// Fills Arrays with constructed objects!
		for(int i = 0; i < 4; i++) {
			currentMapPixCorners[i] = new Point3D();
			currentPartCorners[i] = new Point3D();
		}
		
		long msDone = Calendar.getInstance().getTimeInMillis();
		
		System.out.println("Camera Construction Complete! Took "+(msDone - msStart)+"ms!");
	}
	
	public void run() {
		
		long msStart = Calendar.getInstance().getTimeInMillis();
		
		updateChunks();
		
		orderChunks();
		
		projectMap();
		
		long msDone = Calendar.getInstance().getTimeInMillis();
		
		//System.out.println("This run took "+(msDone - msStart)+"ms!");
		
	}
	
	// Returns the index in a Point(x, z) based on the position of the camera!
	private void currentChunkIndex(Point p){
		p.setLocation((int)pos[0]/Main.IMAGE_SIZE, (int)pos[2]/Main.IMAGE_SIZE);
	}
	
	// Updates the chunks to a buffer for what the camera will render, based on pos!
	private void updateChunks(){
		
		currentChunkIndex(currentChunk);
		
		for(int i = 0; i < chunks.length; i++) {
			for(int j = 0; j < chunks.length; j++) {
				chunks[i][j] = null;
			}
		}
		
		for(int i = -CHUNK_LENGTH / 2; i < CHUNK_LENGTH / 2; i++){
			for(int j = -CHUNK_LENGTH / 2; j < CHUNK_LENGTH / 2; j++){
				
				int refX = (int)currentChunk.getX()+i + 1;
				int refZ = (int)currentChunk.getY()+j + 1;
				int renderX = i+CHUNK_LENGTH/2;
				int renderZ = j+CHUNK_LENGTH/2;
				
				if(refX >= 0 && refZ >= 0){
					chunks[renderX][renderZ] = map.getChunk(refX,refZ);
				}
			}
		}
		
	}
	
	// TODO: Fix some of this code so that entities can be properly loaded onto the screen!
	
	private void orderChunks() {
		orderedChunks.clear();
		for(int i = 0; i < chunks.length; i++) {
			for(int j = 0; j < chunks[0].length; j++) {
				
				Chunk c = chunks[i][j];
				
				if(c==null) {
					continue;
				}
				
				double dist = getDistTo(c.getX(), c.getZ());
				
				
				if(orderedChunks.size()>0) {
					int size = orderedChunks.size();
					int curIndex = size - 1;
					Chunk ic = orderedChunks.get(curIndex);
					double indexDist = getDistTo(ic.getX(), ic.getZ());
					while(dist>indexDist && curIndex>0) {
						ic = orderedChunks.get(curIndex);
						indexDist = getDistTo(ic.getX(), ic.getZ());
						curIndex--;
					}
					orderedChunks.add(c);
					
				} else {
					orderedChunks.add(c);
				}
				
			}
		}
	}
	
	private void orderParts(Chunk c) {
		if(c==null) {
			return;
		}
		orderedParts.clear();
		
		for(int k = 0; k < Chunk.MAX_COMPONENTS; k++) {
			ChunkComponent cc = c.getComponent(k);
			Part[] ps = cc.getParts();
			
			for(int l = 0; l < ps.length; l++) {
				Part part = ps[l];
				
				double dist = getFarthestDist(part);
				
				if(orderedParts.size()>0) {
					int size = orderedParts.size();
					int curIndex = size - 1;
					double indexDist = getFarthestDist(orderedParts.get(curIndex));
					while(dist>indexDist && curIndex>0) {
						indexDist = getFarthestDist(orderedParts.get(curIndex));
						curIndex--;
					}
					orderedParts.add(part);
					
				} else {
					orderedParts.add(part);
				}
			}
		}
	}
	
	private void projectPart(int chunkX, int chunkZ, Part part) {
		if(part==null) {
			return;
		}
		BufferedImage image = part.getImage();
		int orient = part.getOrient();
		int x = part.getX();
		int y = part.getY();
		int width = part.getWidth();
		int length = part.getLength();
		int displacement = part.getDisplacement();
		int componentIndex = part.getComponentIndex();
		
		int curX = 0;
		int curY = 0;
		int curZ = 0;
		
		if(orient==0) {
			curY = componentIndex * Main.IMAGE_SIZE + displacement;
		} else if(orient==1) {
			curY = componentIndex * Main.IMAGE_SIZE + displacement;
		} // TODO: Add other orientations!
		
		for(int ix = 0; ix < width; ix++) {
			if(orient==0) {
				curX = chunkX * Main.IMAGE_SIZE + x + ix;
			} // TODO: Add other orientations!
			
			for(int iy = 0; iy < length; iy++) {
				if(orient==0) {
					curZ = chunkZ * Main.IMAGE_SIZE + y + iy;
				} // TODO: Add other orientations!
				
				if(orient==0 || orient==1) {
					currentMapPixCorners[0].setLocation(curX, curY, curZ);
					currentMapPixCorners[1].setLocation(curX + 1, curY, curZ);
					currentMapPixCorners[2].setLocation(curX + 1, curY, curZ + 1);
					currentMapPixCorners[3].setLocation(curX, curY, curZ + 1);
				} // TODO: Add other orientations!
				
				for(int c = 0; c < 4; c++) {
					project(currentMapPixCorners[c], c);
				}
				
				if(hasIndexWithinImage(projCornersX, projCornersY)) {
					
					int pixX = 0;
					int pixY = 0;
					
					if(orient==0) {
						pixX = ix;
						pixY = iy;
					} else if(orient==1) {
						pixX = width - ix - 1;
						pixY = length - iy - 1;
					} // TODO: Add other orientations!
					
					g2d.setColor(new Color(image.getRGB(pixX, pixY)));
					g2d.fillPolygon(projCornersX, projCornersY, 4);
				}
				
			}
		}
	}
	
	private void projectMap() {
		
		// Makes the entire screen black before reprojecting!
		g2d.setColor(Color.BLACK);
		g2d.fillRect(0, 0, image.getWidth(), image.getHeight());
		
		for(int i = 0; i < orderedChunks.size(); i++) {
			Chunk ic = orderedChunks.get(i);
			orderParts(ic);
			for(int j = 0; j < orderedParts.size(); j++) {
				Part ip = orderedParts.get(j);
				projectPart(ic.getX(), ic.getZ(), ip);
			}
			
		}
				
	//	OLD CODE FOR 3D RENDERING!! BACKUP JUST IN CASE!!!
//		for(int i = 0; i < chunks.length; i++) {
//			for(int j = 0; j < chunks[0].length; j++) {
//				
//				Chunk c = chunks[i][j];
//				
//				if(c!=null) {	
//				
//					int chunkX = c.getX();
//					int chunkZ = c.getZ();
//					
//					for(int k = 0; k < Chunk.MAX_COMPONENTS; k++) {
//						
//						ChunkComponent cc = chunks[i][j].getComponent(k);
//						
//						Part[] ps = cc.getParts();
//						
//						for(int l = 0; l < ps.length; l++) {
//							
//							// Gets all the fields of the current part of a ChunkComponent!
//							Part pt = ps[l];
//							int orient = pt.getOrient();
//							int x = pt.getX();
//							int y = pt.getY();
//							int width = pt.getWidth();
//							int length = pt.getLength();
//							int displacement = pt.getDisplacement();
//							
//							int curX = 0, curY = 0, curZ = 0;
//							
//							if(orient==0) {
//								curY = k * Main.IMAGE_SIZE + displacement;
//							} else if(orient==1) {
//								curY = k * Main.IMAGE_SIZE + Main.IMAGE_SIZE - displacement;
//							} else if(orient==2) {
//								curX = k * Main.IMAGE_SIZE + displacement;
//							} else if(orient==3) {
//								curX = k * Main.IMAGE_SIZE - displacement;
//							} else if(orient==4) {
//								curZ = k * Main.IMAGE_SIZE - displacement;
//							} else {
//								curZ = k * Main.IMAGE_SIZE - displacement;
//							}
//							
//							
//							for(int ix = 0; ix < width; ix++) {
//								
//								if(orient==0) {
//									curX = chunkX * Main.IMAGE_SIZE + x + ix;
//								} else if(orient==1) {
//									curX = chunkX * Main.IMAGE_SIZE + x + (width - ix - 1);
//								} else {
//									curX = 0;
//									curY = 0;
//									curZ = 0;
//								}
//								
//								
//								for(int iy = 0; iy < length; iy++) {
//									
//									if(orient==0) {
//										curZ = chunkZ * Main.IMAGE_SIZE + y + iy;
//										
//									} else if(orient==1) {
//										curZ = chunkZ * Main.IMAGE_SIZE + y + (length - iy - 1);
//									}
//									
//									if(orient==0 || orient==1) {
//										currentMapPixCorners[0].setLocation(curX, curY, curZ);
//										currentMapPixCorners[1].setLocation(curX + 1, curY, curZ);
//										currentMapPixCorners[2].setLocation(curX + 1, curY, curZ + 1);
//										currentMapPixCorners[3].setLocation(curX, curY, curZ + 1);
//									}
//									
//									int projIndex = 0;
//									
//									if(orient==0 || orient==1) {
//										projIndex = 0;
//									}
//									
//									
//									
//									for(int m = 0; m < 4; m++) {
//										project(currentMapPixCorners[m], m);
//									}
//									
//									currentPolygon.xpoints = projCornersX;
//									currentPolygon.ypoints = projCornersY;
//									
//									int minX = min(projCornersX);
//									int maxX = max(projCornersX);
//									
//									int minY = min(projCornersY);
//									int maxY = max(projCornersY);
//									
//									
//									
//									if(withinImage(minX, minY) && withinImage(maxX, maxY)){
//										for(int px = minX; px <= maxX; px++){
//											for(int py = minY; py <= maxY; py++){
//												
//												if( currentPolygon.contains(px, py) ){
//													double dist = getDist(pos[0], pos[1], pos[2], curX, curY, curZ);
//													
//													if(dist<distances[px][py] || distances[px][py]==-1){
//														g2d.setComposite(src_over);
//														distances[px][py] = dist;
//													} else {
//														g2d.setComposite(dst_over);
//													}
//													
//													int pixel = 0;
//													if(orient==0) {
//														pixel = pt.getRGB(ix, iy);
//													} else if(orient==1) {
//														pixel = pt.getRGB(width - ix - 1, length - iy - 1);
//													}
//														
//													g2d.setColor(new Color(pixel));
//													g2d.setColor(Color.BLUE);
//													g2d.fillRect(px,py,1,1);
//													
//													System.out.println(g2d.getColor());
//													
//													g2d.setComposite(src_over);
//				
//																	
//												}
//											}
//										}
//									}
//								}
//							}
//						}
//					}
//				}		
//			}
//		}
		
	}

	// Gets the farthest distance of the part that it accepts!
	private double getFarthestDist(Part part) {
		int orient = part.getOrient();
		int perpValue = 0;
		if(orient==0) {
			perpValue = part.getComponentIndex() * Main.IMAGE_SIZE + part.getDisplacement();
		}
		
		int x = part.getX();
		int y = part.getY();
		int width = part.getWidth();
		int length = part.getLength();
		
		double maxDist = 0;
		
		for(int i = 0; i < 4; i++) {
			double dist = getDistTo(x + (i % 2) * width, perpValue, y + (i / 2) * length);
			if(dist>maxDist) {
				maxDist = dist;
			}
		}
		
		return maxDist;
		
	}
	
	// Returns true if there a point in the arrays that can be shown!
	private boolean hasIndexWithinImage(int[] x, int[] y){
		for(int i = 0; i < x.length; i++) {
			
			int ix = x[i];
			int iy = y[i];
			
			if( (ix>=0 && ix<image.getWidth()) && (iy>=0 && iy<image.getHeight()) ) {
				return true;
			}
		}
		return false;
	}
	
	private double getDistTo(double x, double y) {
		return getDistTo(x,y,0);
	}
	
	// Gets the distance between two three-dimensional points!
	private double getDistTo(double x, double y, double z){
		return Math.sqrt( Math.pow(pos[0] - x, 2) + Math.pow(pos[1] - y, 2) + Math.pow(pos[2] - z, 2) );
	}
	
	// Sets the 2nd parameter based on the 3D point coordinates for the first one by projecting
	// using vector and rotation matrix formula!
	private void project(Point3D p3d, int i) {
		
		double sx = Math.sin(rot[0]);
		double sy = Math.sin(rot[1]);
		double sz = Math.sin(rot[2]);
		
		double cx = Math.cos(rot[0]);
		double cy = Math.cos(rot[1]);
		double cz = Math.cos(rot[2]);
		
		double x = p3d.getX() - pos[0];
		double y = p3d.getY() - pos[1];
		double z = p3d.getZ() - pos[2];
		
		double dx, dy, dz;
		
		double syx = sz*y + cz*x;
		double cyx = cz*y - sz*x;
		
		dx = cy*syx-sy*z;
		dy = sx*( cy*z + sy*syx ) + cx*cyx;
		dz = cx*( cy*z + sy*syx ) - sx*cyx;
		
		double px = surface[2] / dz * dx + surface[0];
		double py = surface[2] / dz * dy + surface[1];
		
		projCornersX[i] = (int)px;
		projCornersY[i] = (int)py;
		
	}
	
	public BufferedImage getImage() {
		return image;
	}
	
	public Graphics2D getGraphics2D() {
		return g2d;
	}
}
