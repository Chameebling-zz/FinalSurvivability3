package render;

import java.awt.*;

public class Projection {
	
	private double dist;
	
	public Projection() {
		// TODO Auto-generated constructor stub
	}

	public double getDist() {
		return dist;
	}

	public void setDist(double dist) {
		this.dist = dist;
	}
}
