package main;


import assets.*;
import map.*;
import render.*;
import screen.*;
import settings.*;

import java.util.*;
import java.awt.*;
import java.io.*;
import javax.swing.*;

public class Main implements Runnable {
	
	public static final String VERSION = "1.0";
	
	public static final int FPS = 60;
	public static final int IMAGE_SIZE = 64;
	
	private ArrayList<GameMap> maps;
	
	private Settings gameSettings;
	private Setting time, difficulty, map, estCoins;
	
	private Thread thread;
	
	// Currency and Profile
	private int coins;
	private long xp;
	
	private boolean running;
	
	private GameFrame frame;
	
	private Screen launch, title, settings, game, shop;
	private Camera cam;
	
	private Player player;
	
	public static void main(String[] args) {
		
		Fonts.loadFonts();
		Images.loadImages();
		
		new Main();

	}
	
	public Main() {
		thread = new Thread(this);
		frame = new GameFrame("Survivability 3");
		frame.setSize(1280, 720);
		
		frame.setBackground(Color.BLACK);
		
		launch = new LaunchScreen(frame, "Launch Screen", 1920, 1080);
		frame.addScreen(launch);
		frame.run();
		
		maps = new ArrayList<GameMap>();
		
		maps.add(new GameMap("Room 319",25,25));
		

		
		initTitleScreen();
		initGameScreen();
		initPlayer();
		
		frame.renderScreen("Title Screen");
		
		
		
		
		// Start the thread!
		start();
	}
	
	private void initTitleScreen() {
		
		gameSettings = new Settings();
		
		time = new Setting("Time");
		time.add("30s");
		time.add("1m");
		time.add("2m");
		time.add("5m");
		
		difficulty = new Setting("Difficulty");
		difficulty.add("Very Easy");
		difficulty.add("Easy");
		difficulty.add("Medium");
		difficulty.add("Hard");
		difficulty.add("Extreme");
		
		
		map = new Setting("GameMap");
		map.add("Room 319");
		
		estCoins = new Setting("Estimated Coins");
		estCoins.add("750");
		
		gameSettings.add(time);
		gameSettings.add(difficulty);
		gameSettings.add(map);
		gameSettings.add(estCoins);
		
		title = new TitleScreen(maps.get(0), frame, "Title Screen", 1920, 1080);
		
				
		Point startTopLeft = new Point(75, 100);
		
		int x = (int)startTopLeft.getX();
		int y = (int)startTopLeft.getY();
		
		title.addButton("START", x, y, 500, 50, Screen.MENU_BUTTON);
		title.addButton(time.toString(), x, y+50, 500, 50, Screen.SUB_BUTTON);
		title.addButton(difficulty.toString(), x, y+100, 500, 50, Screen.SUB_BUTTON);
		title.addButton(map.toString(), x, y+150, 500, 50, Screen.SUB_BUTTON);
		title.addButton(estCoins.toString(), x, y+200, 500, 50, Screen.SUB_BUTTON);
		title.addButton("Edit Game Settings...", x, y+250, 500, 50, Screen.SUB_BUTTON);
		
		title.addButton("SETTINGS", x, y+350, 500, 50, Screen.MENU_BUTTON);
		
		title.addButton("Volume - 100%", x, y+400, 500, 50, Screen.SUB_BUTTON);
		
		//title.addText("Version "+VERSION, 10, 420, Fonts.CONTENT);
		
		frame.addScreen(title);
		
	}
	
	public void initGameScreen(){
		game = new GameScreen(frame, "Game", 1920, 1080);
		
				
		frame.addScreen(game);
	}
	
	public void initPlayer(){
		player = new Player(maps.get(0), (CameraScreen) game, 0, 0, 0, 0, Math.PI / 2, 0);
		game.addKeyListener(player);
		game.addMouseListener(player);
	}
	
	private synchronized void start() {
		running = true;
		thread.start();
	}
	
	public synchronized void stop() {
		running = false;
	}
	
	public void run() {
		
		long upTime = System.nanoTime();
		double ns = 1E9 / FPS;
		double delta = 0;
		frame.requestFocus();
		
		while(running) {
			
			long current = System.nanoTime();
			delta += (current - upTime) / ns;
			upTime = current;
			
			while(delta >= 1) {
				
				// THINGS TO RUN AT DESIRED FPS \/ \/ \/
				
				frame.run();
				player.run();
				
				delta--;
			}
		}
	}
}
