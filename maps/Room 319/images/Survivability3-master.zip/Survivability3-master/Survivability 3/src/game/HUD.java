package game;

import java.awt.*;

public class HUD {
	
	private int max_hp;
	private int hp;
	
	public HUD(int max_hp) {
		
	}
	
	public void draw(Graphics2D g2d) {
		
	}

}
