package game;

public class GameSession {
	
	private long timeLeft;
	private int coinsEarned;
	private int xpEarned;
	
	public GameSession(double time) {
		
	}

}
