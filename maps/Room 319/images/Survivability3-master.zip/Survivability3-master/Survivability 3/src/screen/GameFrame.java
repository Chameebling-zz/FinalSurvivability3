package screen;

import java.util.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import javax.swing.*;

public class GameFrame extends JFrame implements ComponentListener {
	
	private ArrayList<Screen> screens;
	Screen currScreen;
	
	private boolean fullscreen;
	
	public GameFrame(String title) {
		super(title);
		
		screens = new ArrayList<Screen>();
		
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		setResizable(true);
		setLocationRelativeTo(null);
		
		addComponentListener(this);
		
		setVisible(true);
	}
	
	public void run() {
		
		currScreen.run();
	}
	
	public void addScreen(Screen s) {
		getContentPane().add(s);
		screens.add(s);
		
		if(screens.size()==1) {
			currScreen = s;
			renderScreen(s.getName());
		}
	}
	
	public Screen getCurrentScreen() {
		if(screens.size()>=0) {
			return currScreen;
		} else {
			return null;
		}
	}
	
	public void renderScreen(String name){
		currScreen.endRun();
		for(int i = 0; i < screens.size(); i++){
			if(screens.get(i).getName().equals(name)){
				currScreen = screens.get(i);
				currScreen.startRun();
				return;
			}
		}
	}

	@Override
	public void componentHidden(ComponentEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void componentMoved(ComponentEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void componentResized(ComponentEvent e) {
		// TODO Auto-generated method stub
		Screen s = getCurrentScreen();
		
		if(s!=null) {
			s.fitImageIntoFrame();
		}
		
		
	}

	@Override
	public void componentShown(ComponentEvent e) {
		// TODO Auto-generated method stub
		
	}
}
