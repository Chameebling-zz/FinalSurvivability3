package screen;

import javax.swing.*;

public class Component {
	private JComponent component;
	
	private int x, y, width, height;
	
	public Component() {
		
	}
}
