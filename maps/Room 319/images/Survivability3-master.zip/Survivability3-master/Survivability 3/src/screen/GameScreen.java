package screen;

import javax.swing.*;

public class GameScreen extends CameraScreen {

	/**
	 * 
	 */
	
	private static final long serialVersionUID = 632046522747878932L;
	
	public GameScreen(JFrame frame, String name, int width, int height) {
		super(frame, name, width, height);
		
	}
	
	public void run() {
		
		super.run();
		
		
		}

}
