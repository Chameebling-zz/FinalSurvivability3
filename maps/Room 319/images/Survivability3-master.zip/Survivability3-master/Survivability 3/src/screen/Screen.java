package screen;

import java.util.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import javax.swing.*;

import assets.*;

public class Screen extends JPanel implements ActionListener {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 8659340140176518549L;

	public static final int MENU_BUTTON = 0;
	public static final int SUB_BUTTON = 1;
	
	private JFrame frame;
	protected BufferedImage image;
	protected Graphics2D g2d;
	private ArrayList<JComponent> components;
	protected Dimension size, sizeToPaint;
	
	private String name;
	
	public Screen(JFrame frame, String name, int width, int height) {
		image = new BufferedImage(width,height,BufferedImage.TYPE_INT_RGB);
		components = new ArrayList<JComponent>();
		
		size = new Dimension(width, height);
		sizeToPaint = new Dimension(frame.getSize());
		
		g2d = (Graphics2D) image.getGraphics();
		g2d.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER));
		
		this.frame = frame;
		this.name = name;
		
		setLayout(null);
		setPreferredSize(frame.getSize());
		
		frame.add(this);
		frame.pack();
		
		frame.setLocationRelativeTo(null);
		
		setFocusable(true);
		
		repaint();
	}
	
	public void startRun() {
		loadComponents();
	}
	
	public void endRun() {
		removeAll();
	}
	
	public void run() {
		repaint();
	}
	
	// Adds a JButton to the screen.
	public void addButton(final String name, int x, int y, int width, int height, int buttonType) {
		final JButton button = new JButton(name);
		button.setBounds(x, y, width, height);
		
		button.setHorizontalAlignment(SwingConstants.LEFT);
		
		button.setOpaque(false);
		
		button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		
		button.setForeground(Color.WHITE);
		
		if(buttonType==0) {
			
			button.setForeground(Color.WHITE);
			button.setBorderPainted(false);
			button.setFocusPainted(false);
			button.setContentAreaFilled(false);
			button.setFont(Fonts.MAIN);
			
		} else if(buttonType==1) {
			button.setForeground(Color.WHITE);
			button.setBorderPainted(false);
			button.setFocusPainted(false);
			button.setContentAreaFilled(false);
			button.setFont(Fonts.CONTENT);
		}
		
		button.setActionCommand(name.toLowerCase());
		
		button.addActionListener(this);
      
		button.addMouseListener(new MouseAdapter(){
			
			public void mouseEntered(MouseEvent e){
				button.setText(name+" >");
			}
	 
			public void mouseExited(MouseEvent e){
				button.setText(name);
			}
			
		});
		
		components.add(button);
		
	}
	
	// Adds a JLabel to the screen.
	public void addText(String name, int x, int y, Font font) {
		
		System.out.println("Attempting to add JLabel...");
		
		JLabel text = new JLabel(name);
		text.setBounds(x, y, 500, 50);
		text.setFont(font);
		text.setForeground(Color.WHITE);
		components.add(text);
	}
	
	public void fitImageIntoFrame() {
		
		while(sizeToPaint.height<frame.getHeight()) {
			sizeToPaint.width++;
			sizeToPaint.height++;
		}
		
		
	}
	
	public void drawImage(Graphics g) {
		g.drawImage(image, 0, 0, sizeToPaint.width, sizeToPaint.height, null);
	}
	
	public JFrame getFrame(){
		return frame;
	}
	
	// Getter for the BufferedImage field.
	public BufferedImage getImage() {
		return image;
	}
	
	public Graphics2D getGraphics2D() {
		return g2d;
	}
	
	public JComponent[] getComponents() {
		int size = components.size();
		JComponent[] output = new JComponent[size];
		for(int i = 0; i < size; i++) {
			output[i] = components.get(i);
		}
		return output;
	}
	
	public String getName(){
		return name;
	}
	
	public int getWidth() {
		return size.width;
	}
	
	public int getHeight() {
		return size.height;
	}
	
	public void loadComponents() {
		
		for(int i = 0; i < components.size(); i++) {
			add(components.get(i));
		}
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		String action = e.getActionCommand();
		
		if(action.equals("start")) {
			GameFrame f = (GameFrame) frame;
			f.renderScreen("Game");
		}
	}
	
	@Override
	public void paintComponent(Graphics g) {
		g.drawImage(image, 0, 0, sizeToPaint.width, sizeToPaint.height, null);
	}
	
}
