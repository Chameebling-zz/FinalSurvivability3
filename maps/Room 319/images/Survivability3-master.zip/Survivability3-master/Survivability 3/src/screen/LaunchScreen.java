package screen;

import javax.swing.JFrame;

import assets.*;

public class LaunchScreen extends Screen {

	public LaunchScreen(JFrame frame, String name, int width, int height) {
		super(frame, name, width, height);
		
		addText("SURVIVABILITY 3 IS LOADING...", 100, 100, Fonts.MAIN);
	}
	
	public void run() {
		super.run();
		
		
	}

}
