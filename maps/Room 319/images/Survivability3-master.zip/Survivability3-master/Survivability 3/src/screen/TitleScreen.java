package screen;

import assets.*;
import map.*;
import render.*;

import java.awt.*;

import javax.swing.*;

public class TitleScreen extends CameraScreen {

	/**
	 * 
	 */
	
	private static final long serialVersionUID = 632046522747878932L;
	public static final int MAX_DISTORTION_COUNT = 1000;
	
	private Point[] distortions;
		
	private Camera bgCam;
	
	private double[] bgRot;
	
	public TitleScreen(GameMap map, JFrame frame, String name, int width, int height) {
		super(frame, name, width, height);
		distortions = new Point[MAX_DISTORTION_COUNT];		
		bgRot = new double[] {0, Math.PI / 2, 0};
		
		for(int i = 0; i < TitleScreen.MAX_DISTORTION_COUNT; i++) {
			distortions[i] = new Point();
		}
		
		bgCam = new Camera(map, this, new double[] {0, -25, 0}, bgRot, 50);
		setCam(bgCam);
		
	}
	
	public void run() {
		super.run();
		
		Color distort = new Color(127, 127, 127, 200);
 		Graphics2D g2d = getGraphics2D();
 		
 		
 		for(int i = 0; i < TitleScreen.MAX_DISTORTION_COUNT; i++) {
 			
 			int x = (int)(Math.random() * getWidth());
			int y = (int)(Math.random() * getHeight());
			
 			g2d.setColor(distort);
			g2d.fillRect(x, y, 15, 3);
			
 		}
 		
 		bgRot[1]+=Math.PI / 30;
		
 		g2d.drawImage(Images.TITLE, (getWidth() - Images.TITLE.getWidth(null)) / 2, 50, null);
 		
	}

}
