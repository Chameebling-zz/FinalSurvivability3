package assets;

import java.io.*;
import java.awt.*;

import javax.imageio.ImageIO;

public class Images {
	
	public static Image TITLE, ICON;
	
	public static void loadImages() {
		try {
			TITLE = ImageIO.read(new File("images/title.png"));
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
}
