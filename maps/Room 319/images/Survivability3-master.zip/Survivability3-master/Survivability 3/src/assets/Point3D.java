package assets;

import java.awt.Point;

public class Point3D extends Point {
	
	private int z;
	
	public Point3D() {
		super();
	}
	
	public Point3D(int x, int y, int z) {
		super(x,y);
		this.z = z;
	}
	
	public Point3D getLocation() {
		return new Point3D(x,y,z);
	}
	
	public double getZ() {
		return z;
	}
	
	public void move(int x, int y, int z) {
		move(x,y);
		this.z = z;
	}
	
	public void setLocation(int x, int y, int z) {
		move(x,y,z);
	}
	
	public String toString() {
		return "java.awt.Point3D[x="+x+",y="+y+",z="+z+"]";
	}
	
	public void translate(int x, int y, int z) {
		translate(x,y);
		this.z += z;
	}
}
