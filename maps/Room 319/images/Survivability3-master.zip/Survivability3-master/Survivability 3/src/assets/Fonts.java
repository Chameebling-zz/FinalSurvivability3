package assets;

import java.io.*;
import java.awt.*;

public class Fonts {
	public static Font MAIN;
	public static Font CONTENT;
	
	public static void loadFonts() {
		try {
			MAIN = Font.createFont(Font.TRUETYPE_FONT, new File("fonts/blue highway d.ttf")).deriveFont(40F);
			CONTENT = Font.createFont(Font.TRUETYPE_FONT, new File("fonts/PTM55FT.ttf")).deriveFont(20F);
			// TODO add more fonts
			//SUB_MAIN = Font.createFont(Font.TRUETYPE_FONT, new File(""))
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
}
