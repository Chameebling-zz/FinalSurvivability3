package map;

import java.awt.*;

public class ChunkComponentPart {
	
	private Image image;
	private int x, y, z, width, height, depth;
	
	public ChunkComponentPart(){
		
	}
	
	public void setComponentPart(String[] params){
		
	}
}