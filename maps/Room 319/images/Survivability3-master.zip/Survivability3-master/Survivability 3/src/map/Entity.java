package map;

import java.util.*;

public class Entity {
	
	private ArrayList<Part> parts;
	private ArrayList<Interaction> interactions;
	private double gravity = 9.8;
	private boolean movable, ai, hostile;
	
	protected double[] pos, rot;
	
	public Entity(double gravity, boolean movable) {
		parts = new ArrayList<Part>();
		interactions = new ArrayList<Interaction>();
		
		pos = new double[3];
		rot = new double[3];
		
		this.gravity = gravity;
		this.movable = movable;
	}

}
