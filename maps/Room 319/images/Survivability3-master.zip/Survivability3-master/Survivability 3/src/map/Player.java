package map;

import map.*;
import render.*;
import screen.*;

import java.awt.*;
import java.awt.event.*;

public class Player extends Entity implements KeyListener, MouseListener, MouseMotionListener {
	
	private int hp = 100;
	
	private Camera c;
	
	private Graphics2D g2d;
	
	public Player(GameMap map, CameraScreen s, int x, int y, int z, double rx, double ry, double rz) {
		super(9.8, true);
		
		pos[0] = x;
		pos[1] = y;
		pos[2] = z;
		
		rot[0] = rx;
		rot[1] = ry;
		rot[2] = rz;
		
		c = new Camera(map, s, pos, rot, 1000);
		
		s.setCam(c);
	}
	
	public void run() {
		
	}
	
	public void damage(int amt, String cause) {
		hp -= amt;
		if(hp<=0) {
			die(cause);
		}
	}
	
	private void die(String cause) {
		
	}

	@Override
	public void mouseDragged(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseMoved(MouseEvent arg0) {
		System.out.println("MOUSE MOVED!");
		
	}

	@Override
	public void mouseClicked(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyPressed(KeyEvent e) {
		int k = e.getKeyCode();
		
		if(k==KeyEvent.VK_UP){
			pos[0]+=0.1;
		}
	}

	@Override
	public void keyReleased(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyTyped(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}

}
