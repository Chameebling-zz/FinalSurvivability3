package map;

import java.util.*;

public class ChunkComponent {
   
	private ArrayList<Part> parts;
   
	public ChunkComponent(){
		parts = new ArrayList<Part>();
	}
	
	public void add(Part p) {
		parts.add(p);
	}
	
	public Part[] getParts() {
		return parts.toArray(new Part[parts.size()]);
	}
	
	public Part getPart(int index) {
		return parts.get(index);
	}
}