package map;

public class Interaction {
	
	private char key;
	private String name, actionCommand;
	
	public Interaction(char key, String name, String actionCommand){
		this.key = key;
		this.name = name;
		this.actionCommand = actionCommand;
	}
	
}