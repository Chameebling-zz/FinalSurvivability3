package map;

import java.util.*;
import java.io.*;
import java.awt.*;
import java.awt.image.*;
import javax.imageio.*;

public class GameMap {
	   
	public static final String MAP_FOLDER = "maps";
	
	// Width and Length in meters
	private int width, length;
	   
	private String path, name;
	
	// Save for later if there is enough time
	private HashMap componentMap, entityMap, partMap;
	
	private Chunk[][] chunks;
	
	// TODO: Use HashMaps to save space for objects!
	
	public GameMap(String path, String name, int width, int length){
		this(path+"\\"+name, width, length);
	}
	   
	public GameMap(String name, int width, int length){
	      
		// Field assigners
		this.name = name;
		this.width = width;
		this.length = length;
		
		// Constructs and initializes objects involved
	      
		File file = new File(MAP_FOLDER+"\\"+name+"\\map.dat");
		
		componentMap = new HashMap<String, ChunkComponent>();
		entityMap = new HashMap<String, Entity>();
		partMap = new HashMap<String, Part>();
		
		chunks = new Chunk[width][length];
	    
		for(int i = 0; i < chunks.length; i++){
			for(int j = 0; j < chunks[i].length; j++){
				chunks[i][j] = new Chunk(i,j);
			}
		}
		
		scanMapAndPutIntoChunks(file);
		
	}
	
	private void scanMapAndPutIntoChunks(File file){
	   
      // Variables for Part
      Image i = null;
      BufferedImage image = null;
      int orient;
      int x, y, dx, dy, dz;
      
		try{
			Scanner s = new Scanner(file);
	         
			int chunkX = 0;
			int chunkZ = 0;
	         
			Chunk c = null;
         
			// Variables for Part
	         
			while(s.hasNext()){
				String token = s.next();
	            
				int chunkY = 0;
	            
				if(token.equals("chunk")){
	               
					chunkX = s.nextInt();
					chunkZ = s.nextInt();
				} else if(token.equals("component")){
               
					chunkY = s.nextInt();
					
				} else {
					
					// Constructs and sets up HashMap for orientation of Part.
					
					c = chunks[chunkX][chunkZ];
					
					HashMap<String, Integer> orientMap = new HashMap<String, Integer>();
					orientMap.put("up", 0);
					orientMap.put("down", 1);
					orientMap.put("north", 2);
					orientMap.put("south", 3);
					orientMap.put("east", 4);
					orientMap.put("west", 5);
					
					String part = token;
               
					// Handle component part of chunk
	               
					part = part.replace("[","").replace("]","");
	               
					String[] params = part.split(",");
					
					orient = orientMap.get(params[1]);
	               
					x = Integer.parseInt(params[2]);
					y = Integer.parseInt(params[3]);
					dx = Integer.parseInt(params[4]);
					dy = Integer.parseInt(params[5]);
					dz = Integer.parseInt(params[6]);
					
					i = ImageIO.read(new File(MAP_FOLDER+"\\"+name+"\\images\\"+params[0]+".jpg")).getScaledInstance(dx, dy, Image.SCALE_SMOOTH);
	            
					image = new BufferedImage(dx, dy, BufferedImage.TYPE_INT_ARGB);
					
					Graphics2D g2d = image.createGraphics();
					g2d.drawImage(i, 0, 0, null);
					g2d.dispose();
					
					Part chunkPart = new Part(image, orient, x, y, dx, dy, dz, chunkY);
					
					c.addPart(chunkPart, chunkY);
				}
			}
		}catch(Exception e){
	         e.printStackTrace();
		}
	}
	
	public int getWidth() {
		return width;
	}
	
	public int getLength() {
		return length;
	}
	
	public Chunk getChunk(int x, int z){
		return chunks[x][z];
	}
	
}
